    <?php
    // include 'cek.php';
    include 'onek.php';
    require_once 'nav.php';
?>    
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Web Sistem Prediksi Status Gizi</h1>
                        </div>
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Admin
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <div class="alert alert-info">
                                        Selamat Datang Kembali <?=$_SESSION['username']?>. <br> Ini adalah web pengambilan prediksi status gizi. <br><a href="spk.php" class="alert-link">Silahkan Cek Data Balita yang Ada</a>
                                    </div>
                                </div>
                                <!-- .panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>                        <!-- /.col-lg-12 -->
                        <div class="col-lg-12">
                        <center><img class="img-fluid" src="Predik.png" width="30%"><br></center>
                        </div>
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

<?php 
    require_once 'foot.php';
 ?>