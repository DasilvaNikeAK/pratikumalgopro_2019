<?php
date_default_timezone_set('Asia/Jakarta');
include "onek.php";
include "service.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<link rel="icon" href="Predik.png">
	<title>Predik Gizi</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/ionicons.min.css">
	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="css/jquery.timepicker.css">
	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css.css" type="text/css">
	<script src="https://kit.fontawesome.com/b515b9e96a.js" crossorigin="anonymous"></script>
	

</head>

<body>

	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
		<div class="container-fluid px-md-4	">
			<a class="navbar-brand" href="index.php"><i class="fas fa-medkit"></i> Predik Gizi</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="oi oi-menu"></span> Menu
			</button>

			<div class="collapse navbar-collapse" id="ftco-nav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item cta mr-md-1"><a href="login.php" class="nav-link"><i class="fas fa-sign-in-alt"></i> Masuk Admin</a></li>
					<li class="nav-item cta cta-colored"><a href="user/hal.php" class="nav-link"><i class="fa fa-user-circle-o" aria-hidden="true"></i> Masuk User</a></li>
				</ul>
			</div>
		</div>
	</nav>
	<!-- END nav -->

	<div class="hero-wrap img" style="background-image: url(images/bg_3.png);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row d-md-flex no-gutters slider-text align-items-center justify-content-center">
				<div class="col-md-10 d-flex align-items-center ftco-animate">
					<div class="text text-center pt-5 mt-md-5">
						<h1 class="mb-5">Selamat Datang di Web Sistem Prediksi Status Gizi</h1>
					</div>
				</div>
			</div>
		</div>
	</div>

	<section class="ftco-section bg-light">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-xs-12">
					<div class="row justify-content-center pb-3">
						<div class="col-md-12 heading-section ftco-animate">
							<span class="subheading">Status Gizi Terbaru</span>
							<h2 class="mb-4">Menampilkan Setiap Prediksi dari Status Gizi Anak Anda</h2>
						</div>
						<body>
					</div>
				</div>
			</div>
		</div>
	</section>

	<footer class="ftco-footer ftco-bg-dark ftco-section">
		<div class="container">
			<div class="row mb-5">
				<div class="col-md">
					<div class="ftco-footer-widget mb-4">
						<div class="block-23 mb-3">
							<ul>
								<li><i class="fas fa-map-marker-alt" style="margin-right:10px;"></i> <span class="text">Mojosongo, Jebres, Surakarta</span></li>
								<li><i class="fas fa-phone" style="margin-right:10px;"></i> <span class="text">+62 271-717417</span></li>
								<li><i class="fas fa-envelope" style="margin-right:10px;"></i><span class="text">l200190092@student.ums.ac.id</span></li>
								<div><a href="https://www.instagram.com/dasilvaaria/"><img style="margin:5px" src="instagram.png" width="30" height="30" alt="Instagram"></a>
								<a href="https://www.facebook.com/aria.aria.9862"><img style="margin:5px" src="facebook.png" width="30" height="30" alt="Facebook"></a>
								<a href="https://www.youtube.com/channel/UCLBjq9-8xsQyRO4vs_VKBmw" ><img style="margin:5px" src="youtube.png" width="30" height="30" alt="YouTube"></a></div>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 text-center">

					<p>
						Terimakasih Telah Menggunakan Web ini
					</p>
				</div>
			</div>
		</div>
	</footer>


	<!-- loader -->
	<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
			<circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
			<circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00" />
		</svg></div>


	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-migrate-3.0.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/jquery.animateNumber.min.js"></script>
	<script src="js/scrollax.min.js"></script>
	<script src="js/google-map.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
