<?php
	session_start();
	include '../onek.php';

	if (isset($_GET['name'])) {
		
		$id = $_GET['name'];
		mysqli_query($dbcon,"DELETE FROM data_anak WHERE id_data = '$id'");
		echo "<script>alert ('berhasil menghapus')</script>";
		header("location:../nilai.php");

	}else{
		echo "<h1>NGAPAIN WOI</h1>";
	}

?>