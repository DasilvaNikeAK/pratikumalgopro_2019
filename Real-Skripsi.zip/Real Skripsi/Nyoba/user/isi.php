<?php
    include 'oneku.php';
    require_once 'navu.php';
    // if (isset($_GET['id']=='hapus' && $_GET['name'])) {
    //  echo "dihapus.";
    // }
?>
            
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Data Identitas Anak</h1>
                            <a class="btn btn-primary"href="nilai.php">Masukkan Data Alternatif Anak</a><br><br>
                        </div>

                        <div class="col-lg-8">
                            <form role="form" action="" method="POST">
                                <div class="form-group">
                                    <input type="text" required name="nik" class="form-control" placeholder="NIK">
                                </div>
                                <div class="form-group">
                                    <input type="text" required name="nama" class="form-control" placeholder="NAMA">
                                </div>
                                <div class="form-group">
                                    <input type="date" required name="lahir" class="form-control" placeholder="TANGGAL LAHIR">
                                </div>
                                <div class="form-group">
                                    <select name="kelamin" required class="form-control">
                                        <option disabled selected>Jenis Kelamin</option>
                                        <option value="Laki-Laki">Laki-Laki</option>
                                        <option value="Perempuan">Perempuan</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" required name="alamat" class="form-control" placeholder="ALAMAT RUMAH">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="submit" class="form-control btn btn-success form-control" value="SUBMIT" placeholder="submit">
                                </div>
                            </form>
                            <?php
                                if (isset($_POST['submit'])) {
                                    $nik   = $_POST['nik'];
                                    $nama   = $_POST['nama'];
                                    $lahir  = $_POST['lahir'];
                                    $kelamin= $_POST['kelamin'];
                                    $alamat= $_POST['alamat'];
                                    // var_dump($nama,$nik,$lahir,$kelamin,$alamat);
                                    // die;

                                    //sql insert to siswa
                                    $sql = "INSERT INTO anak (nik,nama,lahir,kelamin,alamat)VALUES ('$nik','$nama','$lahir','$kelamin','$alamat')";
                                    $query = mysqli_query($dbcon,$sql);
                                    if ($query) {
                                        echo "<script>alert('berhasil memasukkan data Alternatif')</script>";
                                    }else{
                                        echo "<script>alert('Gagal Memasukkan data')</script>";

                                    }
                                    
                                }else{
                                   
                                }
                            ?>
                        </div>


                        <!-- Menampilkan Tabel Data -->
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    Data Identitas
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>NIK</th>
                                                    <th>Nama</th>
                                                    <th>Tanggal Lahir</th>
                                                    <th>Kelamin</th>
                                                    <th>Alamat Rumah</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!-- mengeluarkan data siswa dari database -->
                                                <?php
                                                   $sql ="SELECT * FROM anak";
                                                   $query = mysqli_query($dbcon, $sql);
                                                   $n = 1 ;
                                                   while ($siswa=mysqli_fetch_array($query)) {
                                                        
                                                ?>
                                                <tr>
                                                    <td><?=$n?></td>
                                                    <td><?=$siswa['nik']?></td>
                                                    <td><?=$siswa['nama']?></td>
                                                    <td><?=$siswa['lahir']?></td>
                                                    <td><?=$siswa['kelamin']?></td>
                                                    <td><?=$siswa['alamat']?></td>
                                                </tr>
                                                <?php
                                                    $n++;
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end Tabel Data -->



                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

<?php 
    require_once 'foot.php';
 ?>