    <?php
    // include 'ceku.php';
    include 'oneku.php';
    require_once 'navu.php';
?>
            
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Sistem Prediksi Status Gizi</h1>
                        </div>
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    User
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <div class="alert alert-info">
                                        Selamat Datang User <br>
                                        Di Website Prediksi Status Gizi, Website ini Berguna untuk mengukur kadar status Gizi pada Anak apakah Anak tersebut memiliki Gizi Baik / Buruk.<br> <a href="isi.php" class="alert-link">Silahkan Masukan Data Anak Anda</a>
                                        <br>(Website Prediksi Status Gizi ini hanya bisa memprediksi Anak Usia 1-2 Tahun)<br>
                                    </div>
                                </div>
                                <!-- .panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>                        <!-- /.col-lg-12 -->
                        <div class="col-lg-12">
                        <center><img class="img-fluid" src="gizi.jpg" width="30%"><img class="img-fluid" src="stunting.jpg" width="30%"><br></center>
                        </div>
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

<?php 
    require_once 'foot.php';
 ?>