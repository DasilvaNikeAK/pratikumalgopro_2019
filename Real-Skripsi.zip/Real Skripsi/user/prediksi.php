<?php
    include 'oneku.php';
    require_once 'navu.php';
?>
            
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">HASIL PREDIKSI STATUS GIZI</h1>
                        </div>
                        <div class="col-lg-12">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIK</th>
                                        <th>Nama</th>
                                        <th>Hasil (BB/U)</th>
                                        <th>Hasil (TB/U)</th>
                                        <th>Gizi</th>

                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $n = 1 ;

                                    $sqljumlah ="SELECT SUM(bobot) FROM kriteria";
                                    $queryjumlah= mysqli_query($dbcon,$sqljumlah);
                                    $jumlah0=mysqli_fetch_array($queryjumlah);
                                    $jumlah = $jumlah0[0];
                                    
                                    // bobot
                                    $sqlkriteria ="SELECT bobot FROM kriteria";
                                    $querykriteria = mysqli_query($dbcon, $sqlkriteria);
                                    $bobot=[];
                                    while ($bariskriteria= mysqli_fetch_array($querykriteria)) {
                                        $bobot[]=$bariskriteria['bobot'];
                                    }
                                    // var_dump($bobot);die();
                                    //end bobot
                                    
                                    //nilai 
                                    $sqlnilai = "SELECT * FROM data_anak";
                                    $querynilai = mysqli_query($dbcon,$sqlnilai);

                                    

                                    while ($barisnilai=mysqli_fetch_array($querynilai)) {  
                                        //nama
                                        $nik= $barisnilai['nik'];
                                        $sqlnama = "SELECT nama FROM anak WHERE nik = $nik";
                                        $namasiswa = mysqli_fetch_array(mysqli_query($dbcon,$sqlnama));
                                        //nilai
                                        $nilaiP = $barisnilai['bb'];
                                        $nilaiK = $barisnilai['tb'];
                                        $umur = 6;
                                        $nilaievaluasi = $nilaiP + $nilaiP - 9;
                                        $nilaievaluasi2 = $nilaiP + $nilaiP - 12;
                                        $nilaievaluasi3 = $nilaiP + $nilaiP - 14; 
                                        $nilaievaluasi4 = $nilaiP + $nilaiP - 16; 
                                        $nilaievaluasi5 = $nilaiP + $nilaiP - 18;
                
                                        if ($umur <= 1){
                                            }else if ($nilaievaluasi >= 23) {
                                            $jurusan = "Lebih";
                                            }else if ($nilaievaluasi >= 7) {
                                            $jurusan = "Baik";
                                            }else {
                                            $jurusan = "Buruk";
                                        }if ($umur <= 2){    
                                            }else if ($nilaievaluasi2 >= 20) {
                                                $jurusan = "Lebih";
                                            }else if ($nilaievaluasi2 >= 10) {
                                                $jurusan = "Baik";
                                            }else {
                                                $jurusan = "Buruk";
                                        }if ($umur <= 3){    
                                            }else if ($nilaievaluasi3 >= 26) {
                                                $jurusan = "Lebih";
                                            }else if ($nilaievaluasi3 >= 15) {
                                                 $jurusan = "Baik";
                                            }else{
                                                $jurusan = "Buruk";
                                        }if ($umur <= 4){    
                                            }else if ($nilaievaluasi4 >= 28) {
                                                $jurusan = "Lebih";
                                            }else if ($nilaievaluasi4 >= 10) {
                                                 $jurusan = "Baik";
                                            }else{
                                                $jurusan = "Buruk";
                                        }if ($umur <= 5){    
                                            }else if ($nilaievaluasi5 >= 32) {
                                                $jurusan = "Lebih";
                                            }else if ($nilaievaluasi5 >= 18) {
                                                 $jurusan = "Baik";
                                            }else{
                                                $jurusan = "Buruk";
                                            }
                                        ?>
                                        <tr>
                                        <td><?=$n?></td>
                                        <td><?=$barisnilai['nik']?></td>
                                        <td><?=$namasiswa['nama'] ?></td>
                                        <td class="text-right"><?=$barisnilai['bb']?></td>
                                        <td class="text-right"><?=$barisnilai['tb']?></td>
                                        <td><?= $jurusan?></td>
                                        </tr>
                                    <?php    
                                    $n++;
                                    }
                                        
                                    ?>
                                    

                               
                                
                                    
                                </tbody>
                            </table>    
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

<?php 
    require_once 'foot.php';
 ?>